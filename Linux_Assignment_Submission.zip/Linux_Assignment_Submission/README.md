# Linux Basics Assignment

## Student Details
Name: Aryan
Environment: Ubuntu on WSL2
Project: Linux Basics

## Tasks Completed

1. File and directory operations
2. Create, rename, move and remove files
3. View files using cat, head and tail
4. Search file contents using grep
5. Inspect Linux users using /etc/passwd
6. Check system information using whoami and uname
7. Check disk and memory using df -h and free -h
8. Create ZIP archives and extract files
9. Change file permissions using chmod
10. Download files using wget
11. Set and display environment variables
12. List directories recursively using ls -R

## Project Structure

- test_dir/: Assignment files and permission exercises
- test_dir.zip: ZIP archive of test_dir
- unzipped_dir/: Extracted archive for verification

## Environment
Operating System: Ubuntu on Windows Subsystem for Linux (WSL2)

## Status
Linux command-line exercises completed.
